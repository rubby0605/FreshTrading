#!/bin/bash
# argument split line by line
# usage : ./argsplt.sh 1 2 3 

for ARG
do
echo python website_create.py $ARG;
done
