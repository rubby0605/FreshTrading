python 1231
grep 1231 DB_stock | awk '{print $2 , $3}' > Data/1231_211115.txt
python 1504
grep 1504 DB_stock | awk '{print $2 , $3}' > Data/1504_211115.txt
python 2308
grep 2308 DB_stock | awk '{print $2 , $3}' > Data/2308_211115.txt
python 2330
grep 2330 DB_stock | awk '{print $2 , $3}' > Data/2330_211115.txt
python 2340
grep 2340 DB_stock | awk '{print $2 , $3}' > Data/2340_211115.txt
python 2344
grep 2344 DB_stock | awk '{print $2 , $3}' > Data/2344_211115.txt
python 2348
grep 2348 DB_stock | awk '{print $2 , $3}' > Data/2348_211115.txt
python 2379
grep 2379 DB_stock | awk '{print $2 , $3}' > Data/2379_211115.txt
python 2454
grep 2454 DB_stock | awk '{print $2 , $3}' > Data/2454_211115.txt
python 2480
grep 2480 DB_stock | awk '{print $2 , $3}' > Data/2480_211115.txt
python 2498
grep 2498 DB_stock | awk '{print $2 , $3}' > Data/2498_211115.txt
python 3008
grep 3008 DB_stock | awk '{print $2 , $3}' > Data/3008_211115.txt
python 3028
grep 3028 DB_stock | awk '{print $2 , $3}' > Data/3028_211115.txt
python 3045
grep 3045 DB_stock | awk '{print $2 , $3}' > Data/3045_211115.txt
python 2526
grep 2526 DB_stock | awk '{print $2 , $3}' > Data/2526_211115.txt
python 2542
grep 2542 DB_stock | awk '{print $2 , $3}' > Data/2542_211115.txt
python 2603
grep 2603 DB_stock | awk '{print $2 , $3}' > Data/2603_211115.txt
python 2609
grep 2609 DB_stock | awk '{print $2 , $3}' > Data/2609_211115.txt
python 2610
grep 2610 DB_stock | awk '{print $2 , $3}' > Data/2610_211115.txt
python 2845
grep 2845 DB_stock | awk '{print $2 , $3}' > Data/2845_211115.txt
python 2880
grep 2880 DB_stock | awk '{print $2 , $3}' > Data/2880_211115.txt
python 2881
grep 2881 DB_stock | awk '{print $2 , $3}' > Data/2881_211115.txt
