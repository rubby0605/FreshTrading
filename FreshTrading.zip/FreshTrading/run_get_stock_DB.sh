while true
do
	python3 get_stock_price.py >> Data/DB_stock 
	sleep 300
done
