echo $#

